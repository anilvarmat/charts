import logo from "./logo.svg";
import "./App.css";
import ChartContainer from "./ChartContainer";

function App() {
  return (
    <div className='App'>
      <ChartContainer />
    </div>
  );
}

export default App;
