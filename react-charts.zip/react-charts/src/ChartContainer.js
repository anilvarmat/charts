import React, { useState } from "react";
import Box from "@mui/material/Box";
import Grid from "@mui/material/Grid";
import Typography from "@mui/material/Typography";
import { styled } from "@mui/material/styles";
import SelectList from "./Select";
import data from "./data";
import {
  BarChart,
  Bar,
  Tooltip,
  CartesianGrid,
  XAxis,
  YAxis,
  Legend
} from "recharts";
import { uniqueValues, getRecordsBySelection } from "./util";

const { records } = data;
const filters = [
  { key: "status", value: "Status" },
  { key: "issue_type", value: "Issue Type" },
  { key: "priority", value: "Priority" }
];

const getFiltersList = filter => uniqueValues(records, filter);

const GridContainer = styled(Grid)(({ theme }) => ({
  padding: theme.spacing(4),
  textAlign: "center",
  color: theme.palette.text.secondary
}));

const ChartContainer = props => {
  const [selection, setSelection] = useState(undefined);
  const [filteredList, setFilteredList] = useState(records);
  const handleChange = obj => {
    const { filterKey, value } = obj;
    setSelection({ ...selection, [filterKey]: value });
  };
  React.useEffect(() => {
    if (selection) {
      const record = getRecordsBySelection(records, selection);
      setFilteredList(record);
    }
  }, [selection]);

  const graphData = [];
  filteredList.reduce((res, value) => {
    if (!res[value.assignee]) {
      res[value.assignee] = { assignee: value.assignee, story_points: 0 };
      graphData.push(res[value.assignee]);
    }
    res[value.assignee].story_points += value.story_points;
    return res;
  }, {});

  return (
    <Box sx={{ flexGrow: 1 }}>
      <GridContainer container spacing={2}>
        <Grid item xs={12}>
          {" "}
          <Typography>Charts</Typography>
        </Grid>
        <Grid item xs={12}>
          <GridContainer container spacing={2}>
            {filters.map(filter => (
              <Grid item xs={3}>
                <SelectList
                  label={filter.value}
                  filterKey={filter.key}
                  list={getFiltersList(filter.key)}
                  handleChange={handleChange}
                />
              </Grid>
            ))}
          </GridContainer>
        </Grid>
        <Grid item xs={12}>
          <BarChart width={1080} height={250} data={graphData}>
            <CartesianGrid strokeDasharray='3 3' />
            <XAxis dataKey='assignee' />
            <YAxis />
            <Tooltip />
            <Legend />
            <Bar dataKey='story_points' fill='#8884d8' />
          </BarChart>
        </Grid>
      </GridContainer>
    </Box>
  );
};

export default ChartContainer;
