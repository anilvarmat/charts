import * as React from "react";
import InputLabel from "@mui/material/InputLabel";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";

export default function SelectList(props) {
  const { filterKey, label, list, handleChange } = props;
  const [value, setValue] = React.useState("");
  const handleSelection = event => {
    setValue(event.target.value);
    handleChange({ filterKey, value: event.target.value });
  };

  return (
    <div>
      <FormControl sx={{ m: 1, minWidth: 80 }}>
        <InputLabel id='demo-simple-select-autowidth-label'>{label}</InputLabel>
        <Select
          labelId='demo-simple-select-autowidth-label'
          id='demo-simple-select-autowidth'
          value={value}
          onChange={handleSelection}
          autoWidth
          label={label}
        >
          {list.map(l => (
            <MenuItem value={l}>{l}</MenuItem>
          ))}
        </Select>
      </FormControl>
    </div>
  );
}
