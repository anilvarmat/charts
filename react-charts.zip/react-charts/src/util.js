export const uniqueValues = (data, key) => [
  ...new Set(data.map(item => item[key]))
];

export const getRecordsBySelection = (data, selection) => {
  const filterKeys = Object.keys(selection);
  const filtered_data = [];
  data.map(d => {
    filterKeys.map(key => {
      if (selection[key] === d[key]) {
        filtered_data.push(d);
      }
    });
  });
  const result = [...new Set(filtered_data)];
  return result;
};
